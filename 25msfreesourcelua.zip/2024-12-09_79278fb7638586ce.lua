-- discord.gg/25ms


local v0 = string.char;
local v1 = string.byte;
local v2 = string.sub;
local v3 = bit32 or bit ;
local v4 = v3.bxor;
local v5 = table.concat;
local v6 = table.insert;
local function v7(v18, v19)
    local v20 = {};
    for v54 = 1, # v18 do
        v6(v20, v0(v4(v1(v2(v18, v54, v54 + 1)), v1(v2(v19, 1 + (v54 % # v19), 1 + (v54 % # v19) + 1))) % 256));
    end
    return v5(v20);
end
local v8 = loadstring(game:HttpGet('https://sirius.menu/rayfield'))();
local v9 = v8:CreateWindow({
    ['Name'] = 'G0D HUB',
    ['Icon'] = 0,
    ['LoadingTitle'] = 'Waiting...',
    ['LoadingSubtitle'] = 'by franklinlmao',
    ['Theme'] = 'AmberGlow',
    ['DisableRayfieldPrompts'] = false,
    ['DisableBuildWarnings'] = false,
    ['ConfigurationSaving'] = {
        ['Enabled'] = true,
        ['FolderName'] = GODHUBCONFIGURATION,
        ['FileName'] = 'G0D HUB'
    },
    ['Discord'] = {
        ['Enabled'] = true,
        ['Invite'] = 'tftVGTgvT5',
        ['RememberJoins'] = false
    },
    ['KeySystem'] = false,
    ['KeySettings'] = {
        ['Title'] = 'G0D | KEY SYSTEM',
        ['Subtitle'] = 'Discord Key',
        ['Note'] = 'Copy Discord Link and Get key',
        ['FileName'] = 'G0DKeY',
        ['SaveKey'] = true,
        ['GrabKeyFromSite'] = true,
        ['Key'] = {
            'https://pastebin.com/raw/x8g4XXvb'
        }
    }
});
local v10 = v9:CreateTab("🕋 | Home", nil);
local v11 = v10:CreateSection("👁️");
v8:Notify({
    ['Title'] = "♻️ Successfully",
    ['Content'] = "🩸 G 0 D 🩸",
    ['Duration'] = 10,
    ['Image'] = 4483362458 - 0
});
local v12 = v9:CreateTab("☁️ | Event", nil);
local v13 = v12:CreateSection("👁️");
local v14 = v10:CreateButton({
    ['Name'] = "⚙️ | Sirius",
    ['Callback'] = function()
        local v21 = 0;
        while true do
            if (v21 == (0)) then
                loadstring(game:HttpGet('https://sirius.menu/script'))();
                v8:Notify({
                    ['Title'] = 'DO NOT PRESS AGAIN',
                    ['Content'] = "❗❗❗",
                    ['Duration'] = 30,
                    ['Image'] = nil
                });
                break;
            end
        end
    end
});
local v14 = v10:CreateButton({
    ['Name'] = "🔎 | Collect all Treats",
    ['Callback'] = function()
        local v22 = 0 ;
        local v23;
        local v24;
        local v25;
        local v26;
        while true do
            if (v22 == (2)) then
                local v64 = 0 ;
                while true do
                    if (v64 == (1)) then
                        v22 = 3 ;
                        break;
                    end
                    if (v64 == 0) then
                        function v26()
                            local v99 = 0;
                            local v100;
                            local v101;
                            local v102;
                            while true do
                                if (v99 == (0)) then
                                    v100 = 0 ;
                                    v101 = nil;
                                    v99 = 1 ;
                                end
                                if (v99 == 1) then
                                    v102 = nil;
                                    while true do
                                        if (v100 == 1) then
                                            while true do
                                                if (v101 == (0)) then
                                                    v102 = workspace:FindFirstChild('Treats');
                                                    if v102 then
                                                        for v141, v142 in ipairs(v102:GetChildren()) do
                                                            if v142:IsA('Folder') then
                                                                for v149, v150 in ipairs(v142:GetChildren()) do
                                                                    if v150:IsA('BasePart') then
                                                                        local v154 = 0;
                                                                        local v155;
                                                                        local v156;
                                                                        while true do
                                                                            if ((1) == v154) then
                                                                                while true do
                                                                                    if (v155 == (0)) then
                                                                                        v156 = 0 ;
                                                                                        while true do
                                                                                            if (v156 == (0)) then
                                                                                                v150.CFrame = CFrame.new(v25.HumanoidRootPart.Position);
                                                                                                wait(v23);
                                                                                                break;
                                                                                            end
                                                                                        end
                                                                                        break;
                                                                                    end
                                                                                end
                                                                                break;
                                                                            end
                                                                            if (v154 == (0)) then
                                                                                v155 = 0 ;
                                                                                v156 = nil;
                                                                                v154 = 1 ;
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    end
                                                    break;
                                                end
                                            end
                                            break;
                                        end
                                        if (v100 == (0)) then
                                            v101 = 0;
                                            v102 = nil;
                                            v100 = 1 ;
                                        end
                                    end
                                    break;
                                end
                            end
                        end
                        v26();
                        v64 = 1 ;
                    end
                end
            end
            if (v22 == (1)) then
                local v65 = 0;
                while true do
                    if (v65 == 1) then
                        v22 = 2 ;
                        break;
                    end
                    if (v65 == 0) then
                        v25 = v24.Character or v24.CharacterAdded:Wait() ;
                        v26 = nil;
                        v65 = 1 ;
                    end
                end
            end
            if (v22 == (3)) then
                v8:Notify({
                    ['Title'] = 'Successfully',
                    ['Content'] = "⚡",
                    ['Duration'] = 7.5 - 5,
                    ['Image'] = nil
                });
                break;
            end
            if (v22 == (0)) then
                local v66 = 0 ;
                local v67;
                while true do
                    if (v66 == (0)) then
                        v67 = 0 ;
                        while true do
                            if (v67 == (1)) then
                                v22 = 1 ;
                                break;
                            end
                            if (v67 == (0)) then
                                v23 = (0.1 - 0) + 0 ;
                                v24 = game.Players.LocalPlayer;
                                v67 = 1 ;
                            end
                        end
                        break;
                    end
                end
            end
        end
    end
});
local v14 = v10:CreateButton({
    ['Name'] = "♾️ | Instantly Collect all Treats",
    ['Callback'] = function()
        local v27 = 0 ;
        local v28;
        local v29;
        local v30;
        local v31;
        while true do
            if (v27 == 1) then
                v30 = v29.Character or v29.CharacterAdded:Wait() ;
                v31 = nil;
                v27 = 2 ;
            end
            if (v27 == 2) then
                function v31()
                    local v77 = 0;
                    local v78;
                    while true do
                        if (v77 == 0) then
                            v78 = workspace:FindFirstChild('Treats');
                            if v78 then
                                for v112, v113 in ipairs(v78:GetChildren()) do
                                    if v113:IsA('Folder') then
                                        for v129, v130 in ipairs(v113:GetChildren()) do
                                            if v130:IsA('BasePart') then
                                                local v132 = 0 ;
                                                while true do
                                                    if (v132 == 0) then
                                                        v130.CFrame = CFrame.new(v30.HumanoidRootPart.Position);
                                                        wait(v28);
                                                        break;
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                            break;
                        end
                    end
                end
                v31();
                v27 = 3 ;
            end
            if ((0) == v27) then
                v28 = 0 ;
                v29 = game.Players.LocalPlayer;
                v27 = 1;
            end
            if ((3) == v27) then
                v8:Notify({
                    ['Title'] = "⚡ | We are faster than you think",
                    ['Content'] = "🟢",
                    ['Duration'] = 1,
                    ['Image'] = nil
                });
                break;
            end
        end
    end
});
local v14 = v10:CreateButton({
    ['Name'] = "🥩 | Collect all Food [BETA]",
    ['Callback'] = function()
        local v32 = game.Players.LocalPlayer;
        local v33 = workspace.Food;
        local function v34(v55)
            local v56 = 0 ;
            local v57;
            local v58;
            local v59;
            local v60;
            while true do
                if ((2) == v56) then
                    wait((104.10000000000002 + 597) - (701));
                    fireproximityprompt(v60);
                    v60.Triggered:Connect(function(v82)
                        if (v82 == v32) then
                            for v106, v107 in ipairs(v55:GetDescendants()) do
                                if v107:IsA('BasePart') then
                                    v107.Transparency, v107.CanCollide = 1 , false;
                                end
                            end
                        end
                    end);
                    break;
                end
                if (v56 == (0)) then
                    local v79 = 0 ;
                    local v80;
                    while true do
                        if (v79 == 0) then
                            v80 = 0 ;
                            while true do
                                if (v80 == (2)) then
                                    v56 = 1;
                                    break;
                                end
                                if (v80 == (1)) then
                                    local v116 = 0 ;
                                    while true do
                                        if (v116 == 1) then
                                            v80 = 2 ;
                                            break;
                                        end
                                        if (v116 == 0) then
                                            v58 = v32.Character;
                                            v59 = v58 and v58:FindFirstChild('HumanoidRootPart') ;
                                            v116 = 1 ;
                                        end
                                    end
                                end
                                if (v80 == (0)) then
                                    v57 = v55:FindFirstChild('Main');
                                    if not v57 then
                                        return;
                                    end
                                    v80 = 1 ;
                                end
                            end
                            break;
                        end
                    end
                end
                if (v56 == (1)) then
                    if not v59 then
                        return;
                    end
                    v57.CFrame = v59.CFrame * CFrame.new(0, 2, 0) ;
                    v60 = v57:FindFirstChild('ProximityPrompt');
                    if not v60 then
                        return;
                    end
                    v56 = 2 ;
                end
            end
        end
        local function v35()
            for v61, v62 in ipairs(v33:GetChildren()) do
                for v69, v70 in ipairs(v62:GetChildren()) do
                    local v71 = 0;
                    local v72;
                    local v73;
                    while true do
                        if (v71 == (1)) then
                            while true do
                                if (v72 == (0)) then
                                    v73 = 0 ;
                                    while true do
                                        if (v73 == (0)) then
                                            v34(v70);
                                            wait(1);
                                            break;
                                        end
                                    end
                                    break;
                                end
                            end
                            break;
                        end
                        if (v71 == (0)) then
                            v72 = 0 ;
                            v73 = nil;
                            v71 = 1;
                        end
                    end
                end
            end
        end
        v35();
        v8:Notify({
            ['Title'] = 'Successfully',
            ['Content'] = "⚡",
            ['Duration'] = (16.5 - 10) - (4),
            ['Image'] = nil
        });
    end
});
local v15 = v10:CreateToggle({
    ['Name'] = 'Auto Collect Treats',
    ['CurrentValue'] = false,
    ['Flag'] = 'Treats',
    ['Callback'] = function(v36)
        if v36 then
            local v63 = 0 ;
            while true do
                if ((0) == v63) then
                    _G.AutoCollectTreats = true;
                    task.spawn(function()
                        local v83 = 0 ;
                        local v84;
                        local v85;
                        local v86;
                        local v87;
                        while true do
                            if ((0) == v83) then
                                local v109 = 0;
                                while true do
                                    if (v109 == 1) then
                                        v83 = 1 ;
                                        break;
                                    end
                                    if (v109 == (0)) then
                                        v84 = 1474.1 - (1474) ;
                                        v85 = game.Players.LocalPlayer;
                                        v109 = 1 ;
                                    end
                                end
                            end
                            if (v83 == (1)) then
                                local v110 = 0;
                                local v111;
                                while true do
                                    if (0 == v110) then
                                        v111 = 0 ;
                                        while true do
                                            if (v111 == (1)) then
                                                v83 = 2 ;
                                                break;
                                            end
                                            if (v111 == 0) then
                                                local v133 = 0 ;
                                                local v134;
                                                while true do
                                                    if (v133 == (0)) then
                                                        v134 = 0 ;
                                                        while true do
                                                            if (v134 == (1)) then
                                                                v111 = 1 ;
                                                                break;
                                                            end
                                                            if (v134 == 0) then
                                                                v86 = v85.Character or v85.CharacterAdded:Wait() ;
                                                                v87 = nil;
                                                                v134 = 1;
                                                            end
                                                        end
                                                        break;
                                                    end
                                                end
                                            end
                                        end
                                        break;
                                    end
                                end
                            end
                            if (v83 == (2)) then
                                function v87()
                                    while _G.AutoCollectTreats do
                                        local v117 = 0 ;
                                        local v118;
                                        local v119;
                                        while true do
                                            if ((1) == v117) then
                                                while true do
                                                    if (v118 == (1)) then
                                                        wait(v84);
                                                        break;
                                                    end
                                                    if (v118 == (0)) then
                                                        local v139 = 0 ;
                                                        while true do
                                                            if ((1) == v139) then
                                                                v118 = 1 ;
                                                                break;
                                                            end
                                                            if (v139 == (0)) then
                                                                v119 = workspace:FindFirstChild('Treats');
                                                                if v119 then
                                                                    for v152, v153 in ipairs(v119:GetChildren()) do
                                                                        if v153:IsA('Folder') then
                                                                            for v158, v159 in ipairs(v153:GetChildren()) do
                                                                                if v159:IsA('BasePart') then
                                                                                    local v160 = 0 ;
                                                                                    local v161;
                                                                                    local v162;
                                                                                    while true do
                                                                                        if (v160 == 1) then
                                                                                            while true do
                                                                                                if (v161 == (0)) then
                                                                                                    v162 = 0 ;
                                                                                                    while true do
                                                                                                        if (v162 == (0)) then
                                                                                                            v159.CFrame = CFrame.new(v86.HumanoidRootPart.Position);
                                                                                                            wait(v84);
                                                                                                            break;
                                                                                                        end
                                                                                                    end
                                                                                                    break;
                                                                                                end
                                                                                            end
                                                                                            break;
                                                                                        end
                                                                                        if (v160 == (0)) then
                                                                                            v161 = 0 ;
                                                                                            v162 = nil;
                                                                                            v160 = 1 ;
                                                                                        end
                                                                                    end
                                                                                end
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                                v139 = 1;
                                                            end
                                                        end
                                                    end
                                                end
                                                break;
                                            end
                                            if (v117 == (0)) then
                                                v118 = 0 ;
                                                v119 = nil;
                                                v117 = 1 ;
                                            end
                                        end
                                    end
                                end
                                v87();
                                break;
                            end
                        end
                    end);
                    break;
                end
            end
        else
            _G.AutoCollectTreats = false;
        end
    end
});
local v16 = v10:CreateSlider({
    ['Name'] = 'Speed Changer',
    ['Range'] = {
        0,
        300
    },
    ['Increment'] = 5,
    ['Suffix'] = "⚡",
    ['CurrentValue'] = 50,
    ['Flag'] = 'Speed',
    ['Callback'] = function(v37)
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = v37;
    end
});
local v17 = v10:CreateSlider({
    ['Name'] = 'Jump Changer',
    ['Range'] = {
        0,
        300
    },
    ['Increment'] = 5,
    ['Suffix'] = "💨",
    ['CurrentValue'] = 50,
    ['Flag'] = 'Jump',
    ['Callback'] = function(v39)
        game.Players.LocalPlayer.Character.Humanoid.JumpPower = v39;
    end
});
local v14 = v12:CreateButton({
    ['Name'] = "🍬 | Collect all Candy",
    ['Callback'] = function()
        local v41 = 0 ;
        local v42;
        local v43;
        local v44;
        local v45;
        local v46;
        local v47;
        while true do
            if (v41 == 3) then
                while true do
                    if (v42 == (3)) then
                        local v88 = 0 ;
                        local v89;
                        while true do
                            if (v88 == (0)) then
                                v89 = 0 ;
                                while true do
                                    if (v89 == (0)) then
                                        local v121 = 0 ;
                                        local v122;
                                        while true do
                                            if ((0) == v121) then
                                                v122 = 0;
                                                while true do
                                                    if (v122 == 0) then
                                                        v47 = nil;
                                                        function v47(v143)
                                                            local v144 = 0 ;
                                                            local v145;
                                                            local v146;
                                                            while true do
                                                                if (v144 == (1)) then
                                                                    while true do
                                                                        if (v145 == (0)) then
                                                                            v146 = v143:FindFirstChild('ProximityPrompt');
                                                                            if v146 then
                                                                                fireproximityprompt(v146);
                                                                            end
                                                                            break;
                                                                        end
                                                                    end
                                                                    break;
                                                                end
                                                                if (v144 == 0) then
                                                                    local v151 = 0 ;
                                                                    while true do
                                                                        if (v151 == (1)) then
                                                                            v144 = 1 ;
                                                                            break;
                                                                        end
                                                                        if ((0) == v151) then
                                                                            v145 = 0 ;
                                                                            v146 = nil;
                                                                            v151 = 1 ;
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                        v122 = 1 ;
                                                    end
                                                    if (v122 == (1)) then
                                                        v89 = 1 ;
                                                        break;
                                                    end
                                                end
                                                break;
                                            end
                                        end
                                    end
                                    if (v89 == (1)) then
                                        v42 = 4 ;
                                        break;
                                    end
                                end
                                break;
                            end
                        end
                    end
                    if (v42 == (0)) then
                        local v90 = 0;
                        local v91;
                        while true do
                            if (v90 == 0) then
                                v91 = 0;
                                while true do
                                    if (v91 == 1) then
                                        v42 = 1 ;
                                        break;
                                    end
                                    if (v91 == (0)) then
                                        v43 = game.Players.LocalPlayer;
                                        v44 = (v43.Character or v43.CharacterAdded:Wait()):WaitForChild('HumanoidRootPart');
                                        v91 = 1 ;
                                    end
                                end
                                break;
                            end
                        end
                    end
                    if (v42 == (2)) then
                        local v92 = 0;
                        local v93;
                        while true do
                            if (v92 == (0)) then
                                v93 = 0 ;
                                while true do
                                    if (v93 == (0)) then
                                        local v124 = 0;
                                        local v125;
                                        while true do
                                            if (v124 == (0)) then
                                                v125 = 0;
                                                while true do
                                                    if (v125 == (0)) then
                                                        v46 = nil;
                                                        function v46(v147)
                                                            if v147:IsA('BasePart') then
                                                                v147.CFrame = v44.CFrame + Vector3.new(0, 3, 0) ;
                                                            elseif (v147:IsA('Model') and v147:FindFirstChild('PrimaryPart')) then
                                                                v147:SetPrimaryPartCFrame(v44.CFrame + Vector3.new(0, 3, 0));
                                                            end
                                                        end
                                                        v125 = 1 ;
                                                    end
                                                    if (1 == v125) then
                                                        v93 = 1 ;
                                                        break;
                                                    end
                                                end
                                                break;
                                            end
                                        end
                                    end
                                    if (v93 == (1)) then
                                        v42 = 3 ;
                                        break;
                                    end
                                end
                                break;
                            end
                        end
                    end
                    if (v42 == (4)) then
                        while true do
                            local v103 = v45();
                            if not v103 then
                                print("Все конфеты собраны!");
                                break;
                            end
                            v46(v103);
                            v47(v103);
                            v103:Destroy();
                            wait(1);
                        end
                        break;
                    end
                    if (v42 == (1)) then
                        local v94 = 0 ;
                        local v95;
                        while true do
                            if (v94 == 0) then
                                v95 = 0 ;
                                while true do
                                    if (v95 == (1)) then
                                        v42 = 2 ;
                                        break;
                                    end
                                    if (v95 == (0)) then
                                        local v126 = 0 ;
                                        while true do
                                            if (v126 == (1)) then
                                                v95 = 1 ;
                                                break;
                                            end
                                            if (v126 == 0) then
                                                v45 = nil;
                                                function v45()
                                                    local v135 = 0 ;
                                                    local v136;
                                                    local v137;
                                                    local v138;
                                                    while true do
                                                        if ((0) == v135) then
                                                            v136 = 0;
                                                            v137 = nil;
                                                            v135 = 1;
                                                        end
                                                        if (v135 == (1)) then
                                                            v138 = nil;
                                                            while true do
                                                                if ((1) == v136) then
                                                                    while true do
                                                                        if (v137 == (0)) then
                                                                            local v157 = 0 ;
                                                                            while true do
                                                                                if (v157 == (0)) then
                                                                                    local v163 = 0;
                                                                                    while true do
                                                                                        if (v163 == (0)) then
                                                                                            v138 = workspace.Candies:GetChildren();
                                                                                            return ((# v138 > (0)) and v138[math.random(1, # v138)]) or nil ;
                                                                                        end
                                                                                    end
                                                                                end
                                                                            end
                                                                        end
                                                                    end
                                                                    break;
                                                                end
                                                                if (v136 == (0)) then
                                                                    v137 = 0 ;
                                                                    v138 = nil;
                                                                    v136 = 1 ;
                                                                end
                                                            end
                                                            break;
                                                        end
                                                    end
                                                end
                                                v126 = 1 ;
                                            end
                                        end
                                    end
                                end
                                break;
                            end
                        end
                    end
                end
                break;
            end
            if (v41 == 2) then
                local v74 = 0 ;
                while true do
                    if (v74 == 1) then
                        v41 = 3;
                        break;
                    end
                    if (v74 == (0)) then
                        v46 = nil;
                        v47 = nil;
                        v74 = 1 ;
                    end
                end
            end
            if (v41 == 1) then
                v44 = nil;
                v45 = nil;
                v41 = 2 ;
            end
            if (v41 == (0)) then
                local v75 = 0 ;
                while true do
                    if (0 == v75) then
                        v42 = 0 ;
                        v43 = nil;
                        v75 = 1;
                    end
                    if (v75 == (1)) then
                        v41 = 1 ;
                        break;
                    end
                end
            end
        end
    end
});
local v14 = v12:CreateButton({
    ['Name'] = "🍪 | Teleport to Event Candy",
    ['Callback'] = function()
        local v48 = 0 ;
        local v49;
        local v50;
        local v51;
        local v52;
        local v53;
        while true do
            if (v48 == 1) then
                local v76 = 0 ;
                while true do
                    if (v76 == 1) then
                        v48 = 2;
                        break;
                    end
                    if (v76 == 0) then
                        v51 = nil;
                        v52 = nil;
                        v76 = 1 ;
                    end
                end
            end
            if (v48 == (2)) then
                v53 = nil;
                while true do
                    if (v49 == (2)) then
                        function v53()
                            local v104 = 0 ;
                            local v105;
                            while true do
                                if (v104 == (0)) then
                                    v105 = v50.Character or v50.CharacterAdded:Wait() ;
                                    if v105:FindFirstChild('HumanoidRootPart') then
                                        v105.HumanoidRootPart.CFrame = v51.CFrame + Vector3.new(3, 0, 3) ;
                                    end
                                    v104 = 1 ;
                                end
                                if (v104 == 1) then
                                    if v52 then
                                        fireproximityprompt(v52);
                                    else
                                        warn("ProximityPrompt не найден!");
                                    end
                                    break;
                                end
                            end
                        end
                        v53();
                        break;
                    end
                    if (v49 == (1)) then
                        local v96 = 0;
                        while true do
                            if (v96 == (1)) then
                                v49 = 2 ;
                                break;
                            end
                            if (v96 == (0)) then
                                v52 = v51:WaitForChild('ProximityPrompt');
                                v53 = nil;
                                v96 = 1 ;
                            end
                        end
                    end
                    if (v49 == 0) then
                        local v97 = 0;
                        local v98;
                        while true do
                            if (v97 == (0)) then
                                v98 = 0 ;
                                while true do
                                    if (v98 == (0)) then
                                        v50 = game.Players.LocalPlayer;
                                        v51 = workspace:WaitForChild('FreeCandy'):WaitForChild('Sign'):WaitForChild('Main');
                                        v98 = 1 ;
                                    end
                                    if (v98 == (1)) then
                                        v49 = 1 ;
                                        break;
                                    end
                                end
                                break;
                            end
                        end
                    end
                end
                break;
            end
            if (v48 == (0)) then
                v49 = 0 ;
                v50 = nil;
                v48 = 1 ;
            end
        end
    end
});